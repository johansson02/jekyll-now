package ch.bbbaden.fvcardpoker.main;

import com.sun.tracing.dtrace.NameAttributes;
import java.io.Serializable;
import java.util.Collections;
import java.util.LinkedList;
import javax.faces.bean.SessionScoped;
import javax.inject.Named;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author miksh
 */
@Named(value = "deck")
@SessionScoped
public class Deck implements Serializable{

    private String url = "images/";
    private LinkedList<Card> deck = new LinkedList<>();
    private final String[] colors = {"c", "d", "h", "s"};

    public Deck() {
        resetDeck();
    }

    public Card draw() {
        Card card = deck.getFirst();
        deck.removeFirst();
        return card;
    }

    public int getDeckSize() {
        return deck.size();
    }

    public void resetDeck() {
        this.deck.clear();

        for (int i = 0; i < 4; i++) {
            deck.add(new Card(2, colors[i] + "2"));
            deck.add(new Card(3, colors[i] + "3"));
            deck.add(new Card(4, colors[i] + "4"));
            deck.add(new Card(5, colors[i] + "5"));
            deck.add(new Card(6, colors[i] + "6"));
            deck.add(new Card(7, colors[i] + "7"));
            deck.add(new Card(8, colors[i] + "8"));
            deck.add(new Card(9, colors[i] + "9"));
            deck.add(new Card(10, colors[i] + "10"));
            deck.add(new Card(11, colors[i] + "11"));
            deck.add(new Card(12, colors[i] + "12"));
            deck.add(new Card(13, colors[i] + "13"));
            deck.add(new Card(14, colors[i] + "14"));
        }

        System.out.println(this.getDeckSize());
        Collections.shuffle(deck);
    }
}
