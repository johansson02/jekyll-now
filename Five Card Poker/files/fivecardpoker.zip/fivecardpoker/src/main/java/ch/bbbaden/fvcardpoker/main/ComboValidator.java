/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.fvcardpoker.main;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author miksh
 */
public class ComboValidator {

    private int highcard = 0;
    private String combo;
    private int comboStrength;

    int nr2, nr3, nr4, nr5, nr6, nr7, nr8, nr9, nr10, nrJ, nrQ, nrK, nrA, colorSpades, colorHearts, colorDiamonds, colorClubs;

    public ComboValidator() {

    }

    public ComboScore validate(ArrayList<Card> hand, String playername) {

        boolean isFlush, isStraight, isRoyal;
        isFlush = isStraight = isRoyal = false;

        nr2 = nr3 = nr4 = nr5 = nr6 = nr7 = nr8 = nr9 = nr10 = nrJ = nrQ = nrK = nrA = colorSpades = colorHearts = colorDiamonds = colorClubs = highcard = 0;

        for (int i = 0; i < hand.size(); i++) {
            Card evaluateThis = hand.get(i);

            switch (evaluateThis.getId().charAt(0)) {
                case 's':
                    colorSpades++;
                    break;
                case 'h':
                    colorHearts++;
                    break;
                case 'd':
                    colorDiamonds++;
                    break;
                case 'c':
                    colorClubs++;
                    break;
            }

            switch (evaluateThis.getValue()) {
                case 2:
                    nr2++;
                    break;
                case 3:
                    nr3++;
                    break;
                case 4:
                    nr4++;
                    break;
                case 5:
                    nr5++;
                    break;
                case 6:
                    nr6++;
                    break;
                case 7:
                    nr7++;
                    break;
                case 8:
                    nr8++;
                    break;
                case 9:
                    nr9++;
                    break;
                case 10:
                    nr10++;
                    break;
                case 11:
                    nrJ++;
                    break;
                case 12:
                    nrQ++;
                    break;
                case 13:
                    nrK++;
                    break;
                case 14:
                    nrA++;
                    break;

            }

        }
        int nrSortArray[] = {nr2, nr3, nr4, nr5, nr6, nr7, nr8, nr9, nr10, nrJ, nrQ, nrK, nrA};
        int colorSortArray[] = {colorSpades, colorHearts, colorDiamonds, colorClubs};

        //determine highcard
        for (int x = 0; x < hand.size(); x++) {
            if (hand.get(x).getValue() > hand.get(highcard).getValue()) {
                highcard = x;
            }
        }
        highcard = hand.get(highcard).getValue();
        System.out.println("high card: " + highcard);

        isFlush = validateFlush(colorSortArray);
        isStraight = validateStraight(nrSortArray);

        if (isFlush && highcard == 14) {
            isRoyal = true;
        }

        if (!isFlush && !isStraight) {
            validatePairCombos(nrSortArray);
        } else {
            if (isRoyal && isFlush) {
                combo = "royal flush";
                comboStrength = 9;
            } else if (isStraight && isFlush) {
                combo = "straight flush";
                comboStrength = 8;
            } else if (isStraight) {
                combo = "straight";
                comboStrength = 4;
            } else if(isFlush){
                combo = "flush";
                comboStrength = 5;
            } else{
                System.out.println("error. Straight flushes not working.");
            }

        }

        return new ComboScore(playername, hand, combo, comboStrength, highcard);

    }

    private Boolean validateFlush(int colorSortArray[]) {
        Boolean returner = false;
        for (int i = 0; i < colorSortArray.length; i++) {
            if (colorSortArray[i] == 5) {
                returner = true;
            }
        }

        return returner;
    }

    private Boolean validateStraight(int nrSortArray[]) {
        boolean repeater = true;
        int i = 0;
        while (repeater && i < 9) {
            if (nrSortArray[i] > 0) {
                repeater = false;
            } else {
                i++;
            }
        }

        if (i < 9 && nrSortArray[i] == 1 && nrSortArray[i + 1] == 1 && nrSortArray[i + 2] == 1 && nrSortArray[i + 3] == 1 && nrSortArray[i + 4] == 1) {
            highcard = i + 6;
            return true;
        } else {
            return false;
        }
    }

    private void validatePairCombos(int nrSortArray[]) {
        int indexOne = -1;
        int indexOneValue = 0;

        int indexTwo = -1;
        int indexTwoValue = 0;

        //The highest possible aamount of pairs is 2, therefore 2 indexes. Ascending, therefore indexTwo = high card.
        for (int i = 0; i < nrSortArray.length; i++) {
            if (nrSortArray[i] > 1) {
                if (indexOne == -1) {
                    indexOne = i;
                    indexOneValue = nrSortArray[i];
                } else {
                    indexTwo = i;
                    indexTwoValue = nrSortArray[i];
                }

            }
        }

        if (indexOneValue + indexTwoValue == 5) {
            highcard = indexTwo + 2;
            combo = "full house";
            comboStrength = 6;
        } else if (indexOneValue == 2 && indexTwoValue == 2) {
            highcard = indexTwo + 2;
            combo = "2 pairs";
            comboStrength = 2;
        } else if (indexOneValue == 4) {
            highcard = indexOne + 2;
            combo = "FOUR-of-a-kind";
            comboStrength = 7;
        } else if (indexOneValue == 3) {
            highcard = indexOne + 2;
            combo = "THREE-of-a-kind";
            comboStrength = 3;
        } else if (indexOneValue == 2) {
            highcard = indexOne + 2;
            combo = "pair";
            comboStrength = 1;
        } else {
            combo = "high card";
            comboStrength = 0;
        }

    }

    public int getHighcard() {
        return highcard;
    }

    public String getCombo() {
        return combo;
    }

    public int getComboStrength() {
        return comboStrength;
    }

}
