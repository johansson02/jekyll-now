/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.fvcardpoker.main;

import java.util.ArrayList;

/**
 *
 * @author miksh
 */
public class ComboScore {
    
    private ArrayList<Card> handcards = new ArrayList<>();
    private ArrayList<String> tiebreaker = new ArrayList<>();
    private String comboName, playername;
    private int comboStrength, highcard;

    public ComboScore(String playername, ArrayList<Card> handcards, String comboName, int comboStrength, int highcard) {
        this.playername = playername;
        this.handcards = handcards;
        this.comboName = comboName;
        this.comboStrength = comboStrength;
        this.highcard = highcard;
    }

    public String getComboName() {
        return comboName;
    }

    public int getComboStrength() {
        return comboStrength;
    }

    public int getHighCard() {
        return highcard;
    }
    
    public void setTiebreaker(String name){
        tiebreaker.add(name);
    }
    
    public ArrayList getTiebreaker(){
        return tiebreaker;
    }

    public String getPlayername() {
        return playername;
    }

    public int getHighcard() {
        return highcard;
    }
    
    public ArrayList<Card> getHandcards(){
        return handcards;
    }
    
    
    
    
}
