/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package ch.bbbaden.fvcardpoker.main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import javafx.scene.control.Alert;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author miksh
 */
@Named(value = "gameController")
@SessionScoped
public class gameController implements Serializable {

    private ArrayList<String> allPlayers;
    private ArrayList<ComboScore> allScores;

    private ComboValidator validator;
    private Evaluator evaluator;

    private boolean checkBox1, checkBox2, checkBox3, checkBox4, checkBox5;
    private int amtOfPlayers = 0;
    private int amtOfRounds = 2;
    private int roundsPlayed = 0;
    private int currentPlayer = 0;
    private int iterat = 0;
    private int resuliterat = 0;
    private Deck deck;
    private Card[] hand = new Card[5];
    private Card card;

    /**
     * Creates a new instance of gameController
     */
    public gameController() {
        allPlayers = new ArrayList<>();

        evaluator = new Evaluator();
        allScores = new ArrayList<>();
        deck = new Deck();
        checkBox1 = checkBox2 = checkBox3 = checkBox4 = checkBox5 = false;
        for (int i = 0; i < 5; i++) {
            hand[i] = deck.draw();
        }
    }

    public String submit() {
        validator = new ComboValidator();
        resuliterat = 0;
        iterat = 0;
        if (checkBox1) {
            hand[0] = deck.draw();
        }
        if (checkBox2) {
            hand[1] = deck.draw();
        }

        if (checkBox3) {
            hand[2] = deck.draw();
        }

        if (checkBox4) {
            hand[3] = deck.draw();
        }
        if (checkBox5) {
            hand[4] = deck.draw();
        }

        if (roundsPlayed < amtOfRounds - 1) {
            roundsPlayed++;
            return "index.xhtml";
        } else {
            ArrayList<Card> handcards = new ArrayList<>();
            Collections.addAll(handcards, hand);
            allScores.add(validator.validate(handcards, allPlayers.get(currentPlayer)));

            if (currentPlayer < allPlayers.size() - 1) {
                nextPlayer();
                currentPlayer++;

                return "index.xhtml";
            } else {

                return "game.xhtml";
            }

        }

    }

    private void nextPlayer() {
        iterat = 0;
        resuliterat = 0;
        roundsPlayed = 0;
        deck.resetDeck();

        for (int i = 0; i < hand.length; i++) {
            hand[i] = deck.draw();
        }
    }

    public String nextGame() {
        iterat = 0;
        resuliterat = 0;
        currentPlayer = 0;
        roundsPlayed = 0;
        allScores.clear();
        deck.resetDeck();

        for (int i = 0; i < hand.length; i++) {
            hand[i] = deck.draw();
        }

        return "index.xhtml";
    }

    public String settingsCheck() {

        if (amtOfPlayers < 1) {
            return "menu.xhtml";
        } else {
            
            for(int i = 0; i < amtOfPlayers; i++){
                allPlayers.add("Player" + (i + 1));
            }
            
            return "index.xhtml";
        }
    }

    public String getCardImage() {

        card = hand[iterat];
        iterat++;

        return card.getUrl();

    }

    public String getCardResult() {
        card = hand[resuliterat];
        resuliterat++;

        return card.getUrl();
    }

    public String getCombo() {
        String returner;
        String highcard;
        ComboScore winnerScore = evaluator.determineWinner(allScores);

        switch (winnerScore.getHighCard()) {

            case 14:
                highcard = "ace";
                break;
            case 13:
                highcard = "king";
                break;
            case 12:
                highcard = "queen";
                break;
            case 11:
                highcard = "jack";
                break;
            default:
                highcard = "" + winnerScore.getHighCard();
                break;
        }

        if (winnerScore.getTiebreaker().size() > 0) {
            String listedTies = "";
            listedTies = listedTies + winnerScore.getTiebreaker().get(0);

            for (int i = 1; i < winnerScore.getTiebreaker().size(); i++) {
                listedTies = listedTies + ", " + winnerScore.getTiebreaker().get(i);
            }

            returner = "Tie! The following players have scored a " + winnerScore.getComboName() + "with a high card " + highcard + ": " + listedTies + "!";

        } else {
            returner = "The winner is " + winnerScore.getPlayername() + "! The winner scored a " + winnerScore.getComboName() + " with a high card of " + highcard + "!";
        }

        for (int i = 0; i < hand.length; i++) {
            hand[i] = winnerScore.getHandcards().get(i);
        }

        return returner;
    }

    public String getHighCard() {
        return "Your high card: " + validator.getHighcard();
    }

    public boolean isCheckBox1() {
        System.out.println(checkBox1);
        return checkBox1;
    }

    public void setCheckBox1(boolean checkBox1) {
        this.checkBox1 = checkBox1;
    }

    public boolean isCheckBox2() {
        return checkBox2;
    }

    public void setCheckBox2(boolean checkBox2) {
        this.checkBox2 = checkBox2;
    }

    public boolean isCheckBox3() {
        return checkBox3;
    }

    public void setCheckBox3(boolean checkBox3) {
        this.checkBox3 = checkBox3;
    }

    public boolean isCheckBox4() {
        return checkBox4;
    }

    public void setCheckBox4(boolean checkBox4) {
        this.checkBox4 = checkBox4;
    }

    public boolean isCheckBox5() {
        return checkBox5;
    }

    public void setCheckBox5(boolean checkBox5) {
        this.checkBox5 = checkBox5;
    }

    public int getAmtOfRounds() {
        return amtOfRounds;
    }

    public void setAmtOfRounds(int amtOfRounds) {
        this.amtOfRounds = amtOfRounds;
    }

    public String getPlayer() {
        return allPlayers.get(currentPlayer);
    }

    public String getTurnCount() {
        String returner = roundsPlayed + 1 + "/" + amtOfRounds + " turns";
        return returner;
    }

    public int getAmtOfPlayers() {

        return amtOfPlayers;
    }

    public void setAmtOfPlayers(int amtOfPlayers) {
        try {
            this.amtOfPlayers = amtOfPlayers;
        } catch (Exception onlyNumbers) {
            System.out.println("only numbers are allowed");
        }
    }

}
