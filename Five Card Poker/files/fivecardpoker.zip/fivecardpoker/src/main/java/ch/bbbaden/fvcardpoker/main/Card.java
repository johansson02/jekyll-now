package ch.bbbaden.fvcardpoker.main;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author miksh
 */
public class Card {

    private int value;
    private String id;
    private String url;

     Card(int value, String id) {
        this.value = value;
        this.id = id;
        this.url = "images/"+id+".png";
    }

   

   

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
    
}