/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ch.bbbaden.fvcardpoker.main;

import java.util.ArrayList;

/**
 *
 * @author miksh
 */
public class Evaluator {
    
    private ComboScore winner;
    
    public ComboScore determineWinner(ArrayList<ComboScore> allScores){
        
        //In short: Compares comboscores of players. If the comboscore is equal, the highcard wins.
        winner = allScores.get(0);
        for(int i = 1; i<allScores.size(); i++){
            if(winner.getComboStrength() <= allScores.get(i).getComboStrength()){
                if(winner.getComboStrength() < allScores.get(i).getComboStrength()){
                    winner = allScores.get(i);
                }else if(winner.getHighCard() < allScores.get(i).getHighCard()){
                    winner = allScores.get(i);
                }else{
                    winner.setTiebreaker(allScores.get(i).getPlayername());
                }
            }
        }
        return winner;
    }
}
